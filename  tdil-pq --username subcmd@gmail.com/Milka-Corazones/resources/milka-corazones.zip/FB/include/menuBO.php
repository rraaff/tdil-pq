<script type="text/javascript">
  jQuery(function(){ 
    jQuery('.jbar').jbar();
  });
</script>

<ul class="jbar">
   <li>
    <a href="#">Milka corazones</a>
    <ul>
      <li><a href="boDailyPrize.php">Manejo de premios</a></li>
      <li><a href="boAppStats.php">Estado de la applicacion</a></li>
      <li><a href="boAppSearch.php">Consultas</a></li>
      <li><a href="boAppParticipationSearch.php">Listado de participaciones</a></li>
    </ul>
  </li>
  <li>
    <a href="./boLogout">Salir</a>
  </li>
</ul>