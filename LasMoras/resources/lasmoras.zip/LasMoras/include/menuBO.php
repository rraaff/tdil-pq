<script type="text/javascript">
  jQuery(function(){ 
    jQuery('.jbar').jbar();
  });
</script>

<ul class="jbar">
  <li>
    <!-- a href="#">Actions</a>
    <ul>
      <li><a href="http://github.com/javan/jbar">Fork me on github</a></li>
      <li><a href="http://github.com/javan/jbar/zipball/master">Download .zip</a></li>
      <li><a href="http://github.com/javan/jbar/tarball/master">Download .tar.gz</a></li>
    </ul>
  </li-->
  <li>
    <a href="boPremiosInstantaneos.php">Manejo de instant win</a>
  </li>
  <li>
    <a href="boSystemUsers.php">Reporte de usuarios</a>
  </li>
  <li>
    <a href="boTickets.php">Reporte de tickets</a>
  </li>
  <li>
    <a href="boLogout.php">Salir</a>
  </li>
</ul>