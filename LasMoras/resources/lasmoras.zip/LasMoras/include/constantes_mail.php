<?php		
	//Defino las constantes para envio de email
	define('SERVER_NAME','http://localhost');
	define('EMAIL_FROM','info@lasmoras.com');
	define('EMAIL_FROM_NAME','Las Moras');
	define('PASSWORD_REMINDER_SUBJECT','Recordatorio de clave');
	define('PASSWORD_REMINDER_BODY_ALT','Para ver correctamente este email usar un visor html.');
	
	define('COMPARTIR_SUBJECT','Sugerencia');
	define('COMPARTIR_BODY_ALT','Para ver correctamente este email usar un visor html.');
	
?>