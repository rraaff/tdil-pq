<?php		
	//Defino las constantes para la base de datos
	define('DB_SERVER','localhost');
	//define('DB_USER','LASMORAS_USER');
	//define('DB_PASS','LASMORAS_USER');
	//define('DB_NAME','LASMORAS');
	
	define('DB_USER','recompensa');
	define('DB_PASS','19.r3C0.73');
	define('DB_NAME','recompensa');
	
	define('SOCIAL_HUB_STANDARD','FALSE');
	define('TWITTER_STAT','Recomendando Las Moras: ');
?>